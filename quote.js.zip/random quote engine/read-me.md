to intialize
1. refrence the script 
2. intialize by passing the HTML Node as function parameter 
3. 
