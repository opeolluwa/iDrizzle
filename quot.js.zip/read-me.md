1. refrence the style sheet (quot.css) file or the minified version (quote.min.css)
2. refrence the javascript (quot.js) file or the minified version (quote.min.js)
3. intialize by passing the HTML Node ID as function parameter to the initializer $quot()

@dev track
created : October 21, 2020
updated : October 23, 2020
